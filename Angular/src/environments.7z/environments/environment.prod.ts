import { firebaseConfig } from './config/firebase-config';

export const environment = {
  production: true,
  firebaseConfig
}
