// TODO: Copiar esse arquivo para firebase-config.ts e implementar os campos.

export const firebaseConfig = {
  apiKey: '<SUA API KEY>',
  authDomain: '<SEU DOMINIO DE AUTENTICACAO>',
  databaseURL: '<O URL DA REAL TIME DATABASE>',
  projectId: '<O ID DO PROJETO>',
  storageBucket: '<SEU STORAGE BUCKET>',
  messagingSenderId: '<SEU ID DO MESSAGINGSENDER>',
  appId: '<O ID DA APP>',
  measurementId: '<SEU MEASUREMENTID>'
};
