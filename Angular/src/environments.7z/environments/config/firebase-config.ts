export const firebaseConfig = {
  apiKey: 'AIzaSyCd550kV_cPLlwX8U-YgOk24gS_lUHK9TQ',
  authDomain: 'maia-music.firebaseapp.com',
  databaseURL: 'https://maia-music.firebaseio.com',
  projectId: 'maia-music',
  storageBucket: 'maia-music.appspot.com',
  messagingSenderId: '936100013565',
  appId: '1:936100013565:web:588d9c23aa4ad51ce0e594',
  measurementId: 'G-ZFV3XJZVJB'
};
